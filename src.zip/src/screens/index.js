import Home from './Home';
import Splash from './Splash';
import Login from './Login';
import SignUp from './SignUp'
import Chat from './Chat';
import Quiz from './Quiz';
import EndQuiz from './EndQuiz';
import Admin from './Admin';
import AdminHome from './AdminHome';
import Rules from './Rules';
export { Home, Splash, Login, SignUp, Chat, Admin, Quiz, EndQuiz, AdminHome, Rules };
