export const SIGNUP_SUCCESS =
  'You are successfull registered. Kindy confirm your email address to approve your account.';
export const REMOVE_ADDRESS = 'Are you sure?';
