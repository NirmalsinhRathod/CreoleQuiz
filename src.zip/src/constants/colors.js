export const LOADER_BG = 'rgba(0, 0, 0, 0.8)';
export const INDICATOR = 'white';
export const LIGHT_GREY = '#d3d3d3';
