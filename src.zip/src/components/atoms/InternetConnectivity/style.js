export default {
    container: {
        backgroundColor: 'black',
        width: '100%',
        position: 'absolute',
        top: 10,
        padding: 15,
    },
    offlineText: {
        color: 'white',
        backgroundColor: 'black',
        textAlign: 'center'
    }
};
