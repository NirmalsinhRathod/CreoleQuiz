import React from 'react';
<<<<<<< HEAD
import { View, Text, TouchableOpacity, ActivityIndicator, Alert, ScrollView, TextInput, Modal, TouchableHighlight, Button } from 'react-native';
=======
import { View, Text, TouchableOpacity, ActivityIndicator, Alert, ScrollView, TextInput, Picker } from 'react-native';
>>>>>>> 6fe469a89072f9c653213154736d02beca3bf977
import { connect } from 'react-redux';
import styles from './style';
import firebase from 'react-native-firebase';
import * as utility from '../../Utillity/util';
import Slider from '@react-native-community/slider';
import color from '../../color'
import RadioButton from '../../components/atoms/RadioButton'
import Header from '../../components/atoms/Header'
import * as IMG from '../../resources/index';
import { Dropdown } from 'react-native-material-dropdown';
import { TagSelect } from 'react-native-tag-select';


class SignUp extends React.Component {
	constructor(props) {
		super(props);
		this.unsubscribe = null;
		this.state = {
			email: 'arpit@gmail.com',
			phone: '7878787878',
			name: 'arpit',
			address: 'ahmedabad',
			experiance: 0,
<<<<<<< HEAD
			password: 'creole@123',
=======
			rate:0,
			password: '',
>>>>>>> 6fe469a89072f9c653213154736d02beca3bf977
			randomString: '',
			designation: '',
			isLoading: false,
			error: '',
			ans1: {},
			ans2: {},
			ans3: {},
<<<<<<< HEAD
			questionData: [
				{ "question": "Question 1" },
				{ "question": "Question 2" },
				{ "question": "Question 3" },
			],
			modalVisible: false,
			user: null,
			message: '',
			codeInput: '',
			phoneNumber: '+91',
			confirmResult: null,
=======
			questionData: [{ question: 'Question 1' }, { question: 'Question 2' }, { question: 'Question 3' }],
			data: [{
				value: 'Wordpress developer',
			}, {
				value: 'PHP developer',
			}, {
				value: 'Mobile developer',
			}],
			skills: [
				{ id: 1, label: 'HTML' },
				{ id: 2, label: 'CSS' },
				{ id: 3, label: 'JavaScript' },
				{ id: 4, label: 'PHP' },
			],
			selectedSkills:[]

>>>>>>> 6fe469a89072f9c653213154736d02beca3bf977
		};

	}
	componentDidMount() {
		this.unsubscribe = firebase.auth().onAuthStateChanged((user) => {
			if (user) {
				this.setState({ user: user.toJSON() });
			} else {
				// User has been signed out, reset the state
				this.setState({
					user: null,
					message: '',
					codeInput: '',
					phoneNumber: '+91',
					confirmResult: null,
				});
			}
		});
	}
	componentWillUnmount() {
		if (this.unsubscribe) this.unsubscribe();
	}
	signIn = () => {
		const { phoneNumber } = this.state;
		this.setState({ message: 'Sending code ...' });
		firebase.auth().signInWithPhoneNumber(phoneNumber)
			.then(confirmResult => this.setState({ confirmResult, message: 'Code has been sent!' }))
			.catch(error => this.setState({ message: `Sign In With Phone Number Error: ${error.message}` }));
	};
	confirmCode = () => {
		const { codeInput, confirmResult } = this.state;
		if (confirmResult && codeInput.length) {
			confirmResult.confirm(codeInput)
				.then((user) => {
					this.setState({ message: 'Code Confirmed!' });
					// alert(JSON.stringify(user)

					let userRef = firebase.database().ref('users/');
					userRef.child(user._user.uid).set({
						'name': this.state.name,
						'email': this.state.email,
						'password': this.state.password,
						'phone': this.state.phoneNumber,
						'address': this.state.address,
						'experiance': this.state.experiance,
						"question1": this.state.ans1,
						'question2': this.state.ans2,
						'question3': this.state.ans3,
						'isAdmin': 0
						// this.setState({ isLoading: false });
						// this.alertSignup()
					})
						.catch((error) => {
							this.setState({ isLoading: false });
							alert(error.message)
						});

					setTimeout(() => {
						this.setState({ modalVisible: false })
						this.props.navigation.navigate('Home')
					}, 1000);

				})
				.catch(error => this.setState({ message: `Code Confirm Error: ${error.message}` }));
		}
	};
	renderPhoneNumberInput() {
		const { phoneNumber } = this.state;
		return (
			<View style={{ padding: 25 }}>
				<Text>Enter phone number:</Text>
				<TextInput
					autoFocus
					style={{ height: 40, marginTop: 15, marginBottom: 15, width: 200, backgroundColor: 'green' }}
					onChangeText={value => this.setState({ phoneNumber: value })}
					placeholder={'Phone number ... '}
					value={phoneNumber}
				/>
				<Button title="Sign In" color="green" onPress={this.signIn} />
			</View>
		);
	}
	renderMessage() {
		const { message } = this.state;
		if (!message.length) return null;
		return (
			<Text style={{ padding: 5, backgroundColor: '#000', color: '#fff' }}>{message}</Text>
		);
	}
	renderVerificationCodeInput() {
		const { codeInput } = this.state;
		return (
			<View style={{ marginTop: 25, padding: 25 }}>
				<Text>Enter verification code below:</Text>
				<TextInput
					autoFocus
					style={{ height: 40, marginTop: 15, marginBottom: 15 }}
					onChangeText={value => this.setState({ codeInput: value })}
					placeholder={'Code ... '}
					value={codeInput}
				/>
				<Button title="Confirm Code" color="#841584" onPress={this.confirmCode} />
				<Button title="Resend OTP" color="#841584" onPress={this.signIn} />
			</View>
		);
	}
	componentDidMount() {
		this.setState({
			randomString: utility.getRandromString(10)
		});
	}
	toggleModal(visible) {
		this.setState({ modalVisible: visible });
	}

	verifyPhone() {
		const { user, confirmResult } = this.state;
		return (
			<View style={styles.containerPhone}>
				<Modal animationType={"slide"} transparent={false}
					visible={this.state.modalVisible}
					onRequestClose={() => { console.log("Modal has been closed.") }}>

					<View style={styles.modal}>
						<View style={{ flex: 1 }}>
							{!user && !confirmResult && this.renderPhoneNumberInput()}
							{this.renderMessage()}
							{!user && confirmResult && this.renderVerificationCodeInput()}
							{user && (
								<View
									style={{
										padding: 15,
										justifyContent: 'center',
										alignItems: 'center',
										backgroundColor: '#77dd77',
										flex: 1,
									}}
								>
									<Image source={{
										uri: 'https://cdn.pixabay.com/photo/2015/06/09/16/12/icon-803718_1280.png'
									}} style={{ width: 100, height: 100, marginBottom: 25 }} />
									<Text style={{ fontSize: 25 }}>Signed In!</Text>
									<Text>{JSON.stringify(user)}</Text>
								</View>
							)}
						</View>

						<TouchableOpacity
							onPress={() => this.toggleModal(!this.state.modalVisible)}
							style={{ height: 50, backgroundColor: 'red', width: 200, position: 'absolute', bottom: 20 }}>

						</TouchableOpacity>
					</View>
				</Modal>

				<TouchableHighlight onPress={() => { this.toggleModal(true) }}>
					<Text style={styles.text}>Open Modal</Text>
				</TouchableHighlight>
			</View>
		)
	}
	checkValidation() {
		const reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		if (this.state.name.trim() === '') {
			alert('Please enter your full name');
		} else if (this.state.email.trim() === '') {
			alert('Please enter your email');
		} else if (reg.test(this.state.email) === false) {
			alert('Please enter a valid email address');
		} else if (this.state.password.trim() === '') {
			alert('Please enter your password');
		} else if (this.state.phone.trim() === '') {
			alert('Please enter your phone number');
		} else if (this.state.address.trim() === '') {
			alert('Please enter your address');
		} else if (this.state.ans1.trim() === '') {
			alert('Please select your answer for Q1');
		} else if (this.state.ans2.trim() === '') {
			alert('Please select your answer for Q2');
		} else if (this.state.ans3.trim() === '') {
			alert('Please select your answer for Q3');
		} else {
<<<<<<< HEAD
			// this.SignUp()
=======
			this.SignUp();
>>>>>>> 6fe469a89072f9c653213154736d02beca3bf977
		}
	}
	alertSignup() {
		Alert.alert('Sign', 'Signup Successfull', [
			{
				text: 'Ok',
				onPress: () => {
					setTimeout(() => {
						this.props.navigation.navigate('Login');
					}, 100);
				}
			}
		]);
	}
	SignUp() {
		// this.setState({ error: '', isLoading: true });
		// const { email, password } = this.state;
<<<<<<< HEAD
		let navigation = this.props.navigation
		firebase.auth().createUserWithEmailAndPassword(this.state.email, this.state.password)
			.then(user => {
				let userRef = firebase.database().ref('users/');
				userRef.child(user.user.uid).set({
					'name': this.state.name,
					'email': this.state.email,
					'password': this.state.password,
					'phone': this.state.phoneNumber,
					'address': this.state.address,
					'experiance': this.state.experiance,
					"question1": this.state.ans1,
					'question2': this.state.ans2,
					'question3': this.state.ans3,
					'isAdmin': 0
				})
				navigation.navigate('Home')

				// this.setState({ isLoading: false });
				// this.alertSignup()
=======
		firebase
			.auth()
			.createUserWithEmailAndPassword(this.state.email, this.state.password)
			.then((user) => {
				let userRef = firebase.database().ref('users/');
				userRef.child(user.user.uid).set({
					name: this.state.name,
					email: this.state.email,
					password: this.state.password,
					phone: this.state.phone,
					address: this.state.address,
					experiance: this.state.experiance,
					question1: this.state.ans1,
					question2: this.state.ans2,
					question3: this.state.ans3,
					isAdmin: 0
				});
				this.setState({ isLoading: false });
				this.alertSignup();
>>>>>>> 6fe469a89072f9c653213154736d02beca3bf977
			})
			.catch((error) => {
				this.setState({ isLoading: false });
				alert(error.message);
			});
	}
	clearState() {
		this.setState({
			email: '',
			password: ''
		});
	}
	renderLoginButton() {
		return (
			<View style={styles.loginContainer}>
				<Text style={styles.loginText}>Already have an account?</Text>
				<Text style={styles.loginLink} onPress={() => this.props.navigation.navigate('Login')}>
					Login
				</Text>
			</View>
		);
	}
	setAnswer1 = (value) => {
		this.setState({ ans1: value });
	};
	setAnswer2 = (value) => {
		this.setState({ ans2: value });
	};
	setAnswer3 = (value) => {
<<<<<<< HEAD
		this.setState({ ans3: value })
	}

	render() {
		if (this.state.modalVisible === true) {
			return (
				<View>
					{this.verifyPhone()}
				</View>
			)
		} else {
			return (
				<ScrollView style={{ paddingTop: 60 }} contentContainerStyle={{ paddingBottom: 70 }} >
					<View style={styles.container}>
						<TextInput
							style={styles.textfieldStyle}
							placeholder={"Full Name"}
							onChangeText={(name) => this.setState({ name })}
							value={this.state.name} />
						<TextInput
							style={styles.textfieldStyle}
							placeholder={"Email Address"}
							keyboardType={'email-address'}
							onChangeText={(email) => this.setState({ email })}
							value={this.state.email} />
						<TextInput
							style={styles.textfieldStyle}
							placeholder={"Password"}
							secureTextEntry={true}
							keyboardType={'default'}
							onChangeText={(password) => this.setState({ password })}
							value={this.state.password} />
						<TextInput
							style={styles.textfieldStyle}
							placeholder={"Phone Number"}
							onChangeText={(phone) => this.setState({ phone })}
							keyboardType={'number-pad'}
							maxLength={10}
							value={this.state.phone} />
						<TextInput
							style={styles.textAreaStyle}
							multiline={true}
							numberOfLines={4}
							placeholder={"Address"}
							maxLength={150}
							onChangeText={(address) => this.setState({ address })}
							value={this.state.address} />
						<View style={styles.sliderContainer}>
							<Slider
								style={styles.slider}
								minimumValue={0}
								maximumValue={15}
								step={1}
								value={this.state.experiance}
								onValueChange={(experiance) => this.setState({ experiance })}
								minimumTrackTintColor="skyblue"
								maximumTrackTintColor="#000000"
							/>
							<Text style={styles.experianceCountText}>{this.state.experiance}</Text>
						</View>
						{<RadioButton getValue={this.setAnswer1} question={this.state.questionData[0].question} />}
						{<RadioButton getValue={this.setAnswer2} question={this.state.questionData[1].question} />}
						{<RadioButton getValue={this.setAnswer3} question={this.state.questionData[2].question} />}
						<TouchableOpacity
							onPress={() => {
								// this.SignUp.bind(this)
								// this.checkValidation()
								firebase.database().ref('users').once('value').then(snapshot => {
									let isRegister = false
									snapshot.forEach(function (snapshot) {
										var obj = snapshot.child('phone').val();
										if (obj === "+918000076128") {
											isRegister = true
										}
									});
									if (isRegister === false) {
										alert("Your are not registered yet, Please singup")
									} else {
										alert("already registered")
									}
								});
								// this.toggleModal(!this.state.modalVisible)
							}}
							style={styles.signupButton}>
							<View>
								{this.state.isLoading === true
									? <ActivityIndicator />
									: <Text style={{ color: 'white' }}>Signup</Text>}
							</View>
						</TouchableOpacity>
						{this.renderLoginButton()}
					</View>

				</ScrollView >
			);
		}
=======
		this.setState({ ans3: value });
	};
	render() {

		return (
			<View>
				<Header title={'SIGNUP'}
					textColor={'white'}
					leftImage={IMG.IC_BACK}
					leftButtonPress={() => {
						this.props.navigation.goBack()
					}} />

				<ScrollView style={styles.container} contentContainerStyle={{ justifyContent: 'center',paddingBottom:60 }}>
					<View>
						<Text style={styles.placeholdertext}>Full Name</Text>
						<TextInput
							style={styles.textfieldStyle}
							//placeholder={"Full Name"}
							onChangeText={(name) => this.setState({ name })}
							value={this.state.name} />
						<Text style={styles.placeholdertext}>Email Address</Text>
						<TextInput
							style={styles.textfieldStyle}
							//placeholder={"Email Address"}
							keyboardType={'email-address'}
							onChangeText={(email) => this.setState({ email })}
							value={this.state.email} />
						{/* <Text style={styles.placeholdertext}>Password</Text>
						<TextInput
							style={styles.textfieldStyle}
							//placeholder={"Password"}
							secureTextEntry={true}
							keyboardType={'default'}
							onChangeText={(password) => this.setState({ password })}
							value={this.state.password} /> */}
						{/* <Text style={styles.placeholdertext}>Phone Number</Text>
						<TextInput
							style={styles.textfieldStyle}
							//placeholder={"Phone Number"}
							onChangeText={(phone) => this.setState({ phone })}
							keyboardType={'number-pad'}
							maxLength={10}
							value={this.state.phone} /> */}
						{/* <Text style={styles.placeholdertext}>Designation</Text> */}
						<View style={styles.dropdownview}>
							<Dropdown
								label='Designation'
								data={this.state.data}
								textColor={color.darkGray}
								itemColor={color.darkGray}
								selectedItemColor={color.darkGray}
								value={this.state.data[0].value}
								onChangeText={(value)=>{
									this.setState({
										designation:value
									})
								}} />
						</View>
						<Text style={styles.placeholdertext}>How many years of programming experiance do you have?</Text>
						<View style={styles.sliderContainer}>
							<Slider
								style={styles.slider}
								minimumValue={0}
								maximumValue={10}
								step={1}
								value={this.state.experiance}
								onValueChange={(experiance) => this.setState({ experiance })}
								minimumTrackTintColor={color.blue}
								maximumTrackTintColor={color.lightGray}/>
							<Text style={styles.experianceCountText}>{this.state.experiance}</Text>
						</View>
						<Text style={styles.placeholdertext}>How much do you rate yourself in Wordpress?</Text>
						<View style={styles.sliderContainer}>
							<Slider
								style={styles.slider}
								minimumValue={0}
								maximumValue={10}
								step={1}
								value={this.state.rate}
								onValueChange={(rate) => this.setState({ rate })}
								minimumTrackTintColor={color.blue}
								maximumTrackTintColor={color.lightGray} />
							<Text style={styles.experianceCountText}>{this.state.rate}</Text>
						</View>
						<Text style={styles.placeholdertext}>What other skills do you have?</Text>
						<View style={{
							marginTop:10
						}}>
							<TagSelect
								data={this.state.skills}
								//max={3}
								ref={(tag) => {
									this.tag = tag;
								}}
								itemStyle={styles.item}
								itemLabelStyle={styles.lable}
								itemStyleSelected={styles.itemSelected}
								itemLabelStyleSelected={styles.lable}
								onItemPress={()=>{
									this.setState({ selectedSkills: this.tag.itemsSelected})
									//alert(JSON.stringify(this.tag.itemsSelected))
								}}
								onMaxError={() => {
									Alert.alert('Ops', 'Max reached');
								}}
							/>
						</View>
						
						{/* {<RadioButton getValue={this.setAnswer1} question={this.state.questionData[0].question} />}
						{<RadioButton getValue={this.setAnswer2} question={this.state.questionData[1].question} />}
						{<RadioButton getValue={this.setAnswer3} question={this.state.questionData[2].question} />} */}
						<TouchableOpacity
							onPress={() => {
								this.SignUp.bind(this);
								this.checkValidation();
							}}
							style={styles.signupButton}
						>
							<Text style={{ color: 'white' }}>
								{this.state.isLoading === true ? <ActivityIndicator /> : 'Sign up'}
							</Text>
						</TouchableOpacity>
						{this.renderLoginButton()}
					</View>
				</ScrollView>
			</View>
		);
>>>>>>> 6fe469a89072f9c653213154736d02beca3bf977
	}
}

const mapStateToProps = (state) => {
	const { loading, userData, isSuccess } = state.auth;
	return {
		loading,
		userData,
		isSuccess
	};
};

export default connect(mapStateToProps)(SignUp);
