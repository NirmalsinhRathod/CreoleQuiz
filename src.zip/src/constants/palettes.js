export const baseStyle = {
 fontWeight: "bold",
 zIndex: 1,
 fontSize: 18,
 lineHeight: 23,
}